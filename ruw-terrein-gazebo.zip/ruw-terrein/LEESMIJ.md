# Ruw terrein voor jouw Gazebo Sim-robot

## Starten
Pak de ZIP volledig uit. Open een terminal in de uitgepakte map `ruw-terrein`.

```bash
bash start_terrain.sh
```

Er wordt een wereld met terrein gestart. Je robot wordt nog niet automatisch geladen.
In een tweede terminal met je gebruikelijke ROS 2-omgeving geladen:

```bash
bash spawn_robot.sh
```

Hiervoor moeten `xacro` en `ros_gz_sim` al in je ROS 2-omgeving beschikbaar zijn.
Dit spawnt de meegeleverde robot op (0, 0, 0.17). De wielradius is 0.15 m,
dus hij begint 2 cm boven het vlakke startvak.
Dit script start geen ROS bridges, robot_state_publisher of teleop.
Gebruik daarvoor je bestaande configuratie. Start niet tegelijk een tweede
Gazebo-wereld of een tweede exemplaar van de robot via je bestaande launch.

Wil je je bestaande launch gebruiken? Laat die `rugged_terrain.world` laden
in plaats van `empty.world`; voeg de uitgepakte map toe aan
`GZ_SIM_RESOURCE_PATH` zodat `meshes/terrain.stl` vindbaar is. Zonder je
launch-bestand kan het exacte launch-argument niet worden vastgesteld.

## Terrein
Alle maten in meter. De wereld heet `default`, net als de oorspronkelijke wereld.
- Gebied: 20 x 20 m, x en y van -10 tot +10.
- Vlak startvak: minimaal 3 x 3 m rond (0, 0), grondhoogte 0.
- Hobbels en kuilen: x = 2 tot 8, y = -3 tot 3, hoogtes tussen ongeveer -0.08 en +0.08.
- Hellingbanen: x = -8 tot -2; omhoog rijden in positieve x-richting.
  - 5 graden: middenlijn y = -6.
  - 10 graden: middenlijn y = -3.
  - 15 graden: middenlijn y = 0.
  - Elke baan heeft 2 m oprit, 2 m plateau en 2 m afrit.
  - Vlakke baanbreedte 2 m; zijstroken van 0.2 m sluiten aan op de bodem.
  - Plateauhoogtes circa 0.175, 0.353 en 0.536 m.
- Blijf tijdens hellingtests op de middenlijn; de zijstroken zijn steiler.

Het terrein is een vaste driehoeksmesh, met dezelfde geometrie voor visual en
collision. Een mesh is hier gebruikt om het pakket zonder externe textures of
heightmap-resources te kunnen laden. Er is geen vlakke grondlaag door de kuilen.
De ondergrond vervormt niet; sneeuw, modder en losse stenen worden niet gemodelleerd.

## Robot en wijziging
De map `robot` bevat werkkopieen van je vier Xacro-bestanden.
In `gazebo_control.xacro` is alleen de geometrieparameterisering aangepast:
- Wielafstand: `base_frame_width + wheel_width` = 0.65 m (was 0.50).
- Wielradius: verwijst naar de bestaande `wheel_radius` = 0.15 m.

De DiffDrive-plugin stuurt beide wielen per zijde aan. Een fysieke ketting en twee
motoren zijn niet afzonderlijk gemodelleerd.

Aandachtspunten in je aangeleverde model:
- Wielen zijn zichtbaar als cilinders, maar hun botsingsvorm is een bol. Het
  contact met obstakels wijkt daardoor af van een echte band.
- Chassismassa is 0.3 kg; vier wielen zijn elk 2 kg, samen circa 8.3 kg.
  Gebruik echte massa's, massaverdeling en aandrijfgegevens voordat je conclusies
  over klimvermogen of motorvermogen trekt.
- Geen vering en geen gekalibreerd banden/slipmodel. Bij tankbesturing is
  zijdelingse slip relevant. Die moet op basis van rijgedrag worden afgesteld.
- Grondwrijving 0.8 is een startwaarde, geen gemeten waarde voor jouw terrein.

## Controleren
Opgezet met gangbare Gazebo Sim-systemen voor Harmonic/Ionic. Jouw exacte
installatie is nog onbekend. Controleer met `gz sim --versions`.
XML, mesh-opbouw, hellinghoeken en bestandsverwijzingen zijn lokaal gecontroleerd.
Gazebo en Xacro zijn hier niet beschikbaar: geen runtime- of rijtest uitgevoerd.
Stuur eventuele terminalfouten en je launch-bestand voor verdere aansluiting.

## Bronnen
- https://gazebosim.org/docs/harmonic/sdf_worlds/
- https://gazebosim.org/api/sim/8/classgz_1_1sim_1_1systems_1_1DiffDrive.html
