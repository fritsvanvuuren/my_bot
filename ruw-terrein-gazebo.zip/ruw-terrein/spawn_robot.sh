#!/usr/bin/env bash
set -euo pipefail
terrain_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
command -v xacro >/dev/null || { echo 'Laad je ROS-omgeving; xacro ontbreekt.' >&2; exit 1; }
command -v ros2 >/dev/null || { echo 'Laad je ROS 2-omgeving.' >&2; exit 1; }
robot_tmp="$(mktemp --suffix=.urdf)"
trap 'rm -f "$robot_tmp"' EXIT
xacro "$terrain_dir/robot/robot.urdf.xacro" -o "$robot_tmp"
ros2 run ros_gz_sim create -world default -name robot -file "$robot_tmp" -x 0 -y 0 -z 0.17
