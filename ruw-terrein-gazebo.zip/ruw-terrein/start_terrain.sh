#!/usr/bin/env bash
set -euo pipefail
terrain_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export GZ_SIM_RESOURCE_PATH="$terrain_dir${GZ_SIM_RESOURCE_PATH:+:$GZ_SIM_RESOURCE_PATH}"
exec gz sim -r "$terrain_dir/rugged_terrain.world" "$@"
